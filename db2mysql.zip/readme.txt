Free Access to MySQL Database Converter

DB2MYSQL Converter is a totally free program that will convert Microsoft Access Databases to MySQL. It's easy fast and accurate MS Access to MySQL Database Converter easily converts database records of Microsoft MS Access databases to MySQL server. 

DB2MYSQL is very easy to use, just follow the simple screens and let the program automatically do all the work for you. We use a very fast conversion algorithm to provide you with the best possible performance level. 

Its Features include: Supports common MySQL data types and attributes. Supports common MS Access column data types and attributes. Works with all versions of MySQL servers running all platforms. Works with MS Access 97, 2000 and XP. Create a dump file. Select tables to transfer. Easy install, uninstall and upgrade. 

Limitations 

Does not convert forms, queries, reports and Visual Basic scripts 
Does not convert system (hidden) tables 

Requirements 

At least 32 MB RAM 
MS Access 7.0 or higher (ODBC is not required) 
Necessary privileges to write into the destination database 

MySQL dump file 

Access-to-MySQL converter allows users to do indirect conversion and get more control over the process. Following this way, the program converts MS Access data into a local MySQL dump file instead of moving it to MySQL server directly. This dump file contains MySQL statements to create all tables and to fill them with the data. Click here to learn how to import dump file into MySQL database. 

Price :

DB2MYSQL Converter is totally free with no limited features.

Download :

Click here to download totally free version of Access-to-MySQL converter. 

Installation

After downloading the zip program you should simply unzip it and run the db2mysql program.

Contact:

William Long
e-mail: williamlone@gmail.com
website:http://www.moon-blog.com